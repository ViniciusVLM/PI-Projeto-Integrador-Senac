# SecureDesk

> Sistema web de Help Desk para gestão de chamados de TI, desenvolvido como Projeto Integrador II do curso de **Análise e Desenvolvimento de Sistemas — Senac** (Grupo 10).

![Angular](https://img.shields.io/badge/Angular-21.2-DD0031?style=for-the-badge&logo=angular&logoColor=white)
![Node.js](https://img.shields.io/badge/Node.js-Express-339933?style=for-the-badge&logo=nodedotjs&logoColor=white)
![TypeScript](https://img.shields.io/badge/TypeScript-5.9-3178C6?style=for-the-badge&logo=typescript&logoColor=white)

---

## Sobre o projeto

O **SecureDesk** centraliza o suporte de TI de uma empresa: usuários abrem chamados, técnicos assumem e resolvem os atendimentos e administradores gerenciam usuários, equipamentos e categorias, acompanhando tudo por um dashboard.

A aplicação tem arquitetura desacoplada: um front-end em **Angular** que consome uma API REST em **Node.js/Express**. A API grava os dados no arquivo `server/db.json`. Os scripts da pasta `database/` descrevem o mesmo modelo de dados em SQL.

### Perfis de usuário

| Perfil | O que faz |
|--------|-----------|
| Cliente | Abre chamados, acompanha status e histórico, atualiza seus dados |
| Técnico | Assume chamados, altera status e prioridade, adiciona observações |
| Administrador | Gerencia usuários, equipamentos e categorias e consulta indicadores |

### Fluxo de status do chamado

`ABERTO` → `EM ANÁLISE` → `EM ATENDIMENTO` → `AGUARDANDO USUÁRIO` → `RESOLVIDO` → `ENCERRADO` (ou `CANCELADO`)

---

## Situação atual (Entrega 1)

**Telas implementadas no front-end**

| Rota | Tela | Acesso |
|------|------|--------|
| `/` | Home (abertura da aplicação) | Público |
| `/login` | Login | Público |
| `/cadastro` | Cadastro | Público |
| `/esquecisenha` | Esqueci minha senha | Público |
| `/dashboard` | Dashboard | Exige login |

**API (back-end):** autenticação, usuários, chamados, categorias, equipamentos e dashboard.

**Prototipadas, a implementar nas próximas entregas:** lista, novo chamado e detalhes do chamado, usuários, equipamentos, categorias, relatórios e configurações. Os protótipos estão na ficha de prototipagem, na pasta `entrega-1/`.

---

## Tecnologias

| Camada | Tecnologia |
|--------|------------|
| Front-end | Angular 21, TypeScript 5.9, HTML5 e CSS3 (um `.html` e um `.css` por componente) |
| Back-end | Node.js, Express 4, CORS |
| Dados | Arquivo JSON (`server/db.json`) e scripts SQL em `database/` |
| Ferramentas | Angular CLI, Git e GitHub |

---

## Estrutura do projeto

```
PI-Projeto-Integrador-Senac/
├── database/            # Scripts SQL (criação, dados iniciais e consultas)
├── public/              # Arquivos estáticos (imagens)
├── server/              # API REST (Express)
│   ├── routes/          # Rotas: auth, usuários, chamados, categorias...
│   ├── middleware/      # Autenticação por token
│   ├── db.json          # Dados da aplicação
│   └── index.js         # Ponto de entrada da API
├── src/app/
│   ├── core/            # AuthService, guards e interceptor
│   ├── dashboard/       # Tela de dashboard
│   ├── helpdesk/        # Login, cadastro e esqueci minha senha
│   └── home/            # Tela de abertura (Home)
├── angular.json
└── package.json
```

---

## Como executar

**Pré-requisito:** [Node.js](https://nodejs.org/) **20.19 ou superior** (ou 22.12+), exigido pelo Angular 21.

```bash
# 1. Clonar e entrar na pasta
git clone https://github.com/ViniciusVLM/PI-Projeto-Integrador-Senac.git
cd PI-Projeto-Integrador-Senac

# 2. Instalar as dependências (apenas na pasta raiz)
npm install

# 3. Subir a API, em um terminal (http://localhost:3000)
npm run server

# 4. Subir o front-end, em outro terminal (http://localhost:4200)
npm start
```

Os dois comandos de execução precisam ficar abertos ao mesmo tempo.

### Usuários de teste

| E-mail | Perfil | Senha |
|--------|--------|-------|
| joao.silvia@empresa.com | Cliente | 123456 |
| fernanda.souza@empresa.com | Técnico | 123456 |
| carlos.lima@empresa.com | Administrador | 123456 |

### Testes da API

Com a API rodando, em outro terminal:

```bash
node server/test-api.js
```

Esse script cria registros de teste e altera o `server/db.json`. Para voltar os dados ao original: `git checkout server/db.json`.

### Build de produção

```bash
npm run build
```

---

## Equipe — Grupo 10

| Integrante | Função |
|------------|--------|
| Vinicius Lourenço | Back-end, testes e administração do repositório |
| Nicolas Mendes | Front-end (líder) |
| Ariel Rufino | Front-end |
| Giovanna Galichio | Banco de dados |
| Matheus Batista | Documentação |

---

## Licença

Projeto desenvolvido para fins educacionais, como Projeto Integrador do **Senac — Análise e Desenvolvimento de Sistemas**.
