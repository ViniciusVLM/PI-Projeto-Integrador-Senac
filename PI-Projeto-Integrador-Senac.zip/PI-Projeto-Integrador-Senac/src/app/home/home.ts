import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

interface Recurso {
  icone: string;
  titulo: string;
  descricao: string;
}

interface PerfilAcesso {
  icone: string;
  nome: string;
  funcoes: string[];
}

interface Etapa {
  titulo: string;
  descricao: string;
}

@Component({
  selector: 'app-home',
  imports: [RouterLink],
  templateUrl: './home.html',
  styleUrl: './home.css',
})
export class Home {
  readonly anoAtual = new Date().getFullYear();

  readonly recursos: Recurso[] = [
    {
      icone: 'bx-receipt',
      titulo: 'Abertura de chamados',
      descricao: 'Registre problemas com categoria, prioridade e equipamento relacionado.',
    },
    {
      icone: 'bx-git-compare',
      titulo: 'Acompanhamento de status',
      descricao: 'Do chamado aberto ao encerrado, com histórico e observações do técnico.',
    },
    {
      icone: 'bx-bar-chart-alt-2',
      titulo: 'Dashboard de indicadores',
      descricao: 'Visão geral por status, prioridade e categoria para decisões rápidas.',
    },
    {
      icone: 'bx-laptop',
      titulo: 'Controle de equipamentos',
      descricao: 'Cadastre equipamentos, números de patrimônio e usuários responsáveis.',
    },
    {
      icone: 'bx-user',
      titulo: 'Gestão de usuários',
      descricao: 'Perfis de cliente, técnico e administrador, cada um com suas permissões.',
    },
    {
      icone: 'bx-purchase-tag',
      titulo: 'Categorias organizadas',
      descricao: 'Hardware, software, rede, impressora, e-mail, acesso e outras.',
    },
  ];

  readonly perfis: PerfilAcesso[] = [
    {
      icone: 'bx-user',
      nome: 'Cliente / Funcionário',
      funcoes: [
        'Abrir chamados de suporte',
        'Acompanhar status e histórico',
        'Atualizar seus dados',
      ],
    },
    {
      icone: 'bx-support',
      nome: 'Técnico',
      funcoes: [
        'Assumir chamados',
        'Alterar status e prioridade',
        'Adicionar observações e encerrar',
      ],
    },
    {
      icone: 'bx-shield-alt-2',
      nome: 'Administrador',
      funcoes: [
        'Gerenciar usuários, equipamentos e categorias',
        'Visualizar o dashboard',
        'Consultar indicadores',
      ],
    },
  ];

  readonly etapas: Etapa[] = [
    { titulo: 'Abertura', descricao: 'O usuário registra o chamado, que entra como Aberto.' },
    { titulo: 'Análise', descricao: 'Um técnico avalia o caso e define a prioridade.' },
    { titulo: 'Atendimento', descricao: 'O técnico trabalha na solução e registra observações.' },
    { titulo: 'Resolução', descricao: 'O chamado é marcado como Resolvido.' },
    { titulo: 'Encerramento', descricao: 'O usuário confirma e o chamado é encerrado.' },
  ];

  rolarPara(id: string): void {
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }
}
